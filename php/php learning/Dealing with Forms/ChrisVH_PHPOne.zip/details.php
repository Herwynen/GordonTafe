<html>
<body>

Your firstname is: <?php echo $_GET["firstname"]; ?><br>
Your surname is: <?php echo $_GET["surname"]; ?><br>
Your email address is: <?php echo $_GET["email"]; ?> <br>
Your postcode is: <?php echo $_GET["postcode"]; ?> <br>
</body>
</html> 