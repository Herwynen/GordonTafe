<html>
<body>

Welcome <?php echo $_GET["name"]; ?><br>
Your rego is: <?php echo $_GET["rego"]; ?>

</body>
</html> 