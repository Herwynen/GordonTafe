<html>
<body>

Your name is: <?php echo $_GET["Name"]; ?><br>
Your height is: <?php echo (double)$_GET["Height"]; ?> meters.

</body>
</html> 