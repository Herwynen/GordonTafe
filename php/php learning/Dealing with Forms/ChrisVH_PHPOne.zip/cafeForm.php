<html>
<body>

Your Firstname is: <?php echo $_GET["firstname"]; ?><br>
Your Surname is: <?php echo $_GET["surname"]; ?><br>
Your Student ID is: <?php echo $_GET["id"]; ?> <br>
The Campus you attend is: <?php echo $_GET["campus"]; ?> <br>
You rated the food a: <?php echo $_GET["rating"]; ?> <br>
You spend an average: <?php echo $_GET["spend"]; ?> <br>
Comments: <?php echo $_GET ["comment"]; ?> <br>
</body>
</html> 