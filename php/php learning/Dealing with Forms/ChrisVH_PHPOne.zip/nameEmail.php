<html>
<body>

Your username is: <?php echo $_GET["username"]; ?><br>
Your email address is: <?php echo $_GET["email"]; ?>

</body>
</html> 