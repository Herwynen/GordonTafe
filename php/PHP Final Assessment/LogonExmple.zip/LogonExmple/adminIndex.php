<!doctype html>
<html>
<h1> Welcome to Admin Index</h1>
<a href = "logout.php"> Logout </a>
</html>